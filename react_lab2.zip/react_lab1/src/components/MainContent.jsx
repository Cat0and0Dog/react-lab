import React from 'react';
import { Container, Row, Col, Button, Card } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom'; 

function MainContent() {
    const navigate = useNavigate();

    return (
        <Container className="mt-4">
            <Row>
                <Col md={6}>
                    <h2>Welcome to React with Bootstrap</h2>
                    <p>This is lab #2 of integrating Bootstrap into a React project.</p>
                    <Button variant="primary" href="https://github.com/Cat0and0Dog/react-lab.git">Learn More</Button>
                </Col>
                <Col md={6}>
                    <Card>
                        <Card.Body>
                            <Card.Title>Bootstrap Card</Card.Title>
                            <Card.Text>Performed by a student of the group ITEM-24-1 Semchyshyn Y. Y.</Card.Text>
                            <Button variant="success" onClick={() => navigate('/about')}>
                                Go to About Page
                            </Button>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
}

export default MainContent;
