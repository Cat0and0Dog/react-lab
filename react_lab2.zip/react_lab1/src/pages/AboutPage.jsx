import React from "react";
import { Container } from "react-bootstrap";

function AboutPage() {
    return (
        <Container className="mt-4">
            <h2>About This Project</h2>
            <p>
                This page provides more information about the project:{" "}
                <a href="https://github.com/Cat0and0Dog/react-lab.git" target="_blank" rel="noopener noreferrer">
                    GitHub Repository
                </a>
            </p>
        </Container>
    );
}

export default AboutPage;
